import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { About } from "@/components/About";
import { Menu } from "@/components/Menu";
import { Offers } from "@/components/Offers";
import { Gallery } from "@/components/Gallery";
import { Chefs } from "@/components/Chefs";
import { Reservation } from "@/components/Reservation";
import { OrderOnline } from "@/components/OrderOnline";
import { Reviews } from "@/components/Reviews";
import { Contact } from "@/components/Contact";
import { Footer } from "@/components/Footer";
import { WhatsAppButton } from "@/components/WhatsAppButton";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "AL Jannat Bakers & Cafeteria — Fresh Food, Great Mood | Dahranwala" },
      { name: "description", content: "Premium 24/7 restaurant in Dahranwala, Pakistan — wood-fired pizza, BBQ, burgers, fast food, cafe & desserts. Reserve a table or order online." },
      { property: "og:title", content: "AL Jannat Bakers & Cafeteria — Fresh Food, Great Mood" },
      { property: "og:description", content: "Premium dark-themed dining in Dahranwala. Pizza, BBQ, burgers & cafe — open 24 hours." },
      { property: "og:type", content: "website" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <Navbar />
      <main>
        <Hero />
        <About />
        <Menu />
        <Offers />
        <Gallery />
        <Chefs />
        <Reservation />
        <OrderOnline />
        <Reviews />
        <Contact />
      </main>
      <Footer />
      <WhatsAppButton />
    </div>
  );
}
