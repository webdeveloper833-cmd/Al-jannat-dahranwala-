import chef1 from "@/assets/chef1.jpg";
import chef2 from "@/assets/chef2.jpg";
import chef3 from "@/assets/chef3.jpg";
import { Instagram } from "lucide-react";

const chefs = [
  { img: chef1, name: "Chef Imran Ali", role: "Head Chef · Pizza & Pasta", bio: "12 years mastering wood-fired Italian classics with a local twist." },
  { img: chef2, name: "Chef Bilal Hassan", role: "Master Baker", bio: "Crafting fresh breads, cakes & pastries from dawn till dusk." },
  { img: chef3, name: "Chef Usman Khan", role: "BBQ Grill Master", bio: "Specialist in flame-kissed kebabs and authentic desi BBQ." },
];

export function Chefs() {
  return (
    <section id="chefs" className="py-28 relative overflow-hidden">
      <div className="container mx-auto px-5">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-xs uppercase tracking-[0.3em] text-accent font-semibold">The Artisans</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold mt-4 mb-4">
            Meet our <span className="text-gradient-gold">master chefs</span>
          </h2>
          <p className="text-muted-foreground">The talented hands behind every memorable bite.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {chefs.map((c, i) => (
            <div key={c.name} className="group relative animate-fade-up" style={{ animationDelay: `${i * 120}ms` }}>
              <div className="relative rounded-3xl overflow-hidden shadow-card hover-lift">
                <img src={c.img} alt={c.name} loading="lazy" className="w-full h-[460px] object-cover transition-transform duration-700 group-hover:scale-105" />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
                <div className="absolute bottom-0 inset-x-0 p-6">
                  <div className="text-xs uppercase tracking-[0.25em] text-accent mb-1">{c.role}</div>
                  <h3 className="font-display text-2xl font-bold mb-2">{c.name}</h3>
                  <p className="text-sm text-muted-foreground mb-4">{c.bio}</p>
                  <a href="#" className="inline-flex items-center gap-2 text-sm text-primary hover:text-accent transition-colors">
                    <Instagram className="w-4 h-4" /> Follow
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
