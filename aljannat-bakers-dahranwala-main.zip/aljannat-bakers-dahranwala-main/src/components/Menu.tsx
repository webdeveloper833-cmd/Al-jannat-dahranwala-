import { useState } from "react";
import pizza from "@/assets/pizza.jpg";
import burger from "@/assets/burger.jpg";
import bbq from "@/assets/bbq.jpg";
import fastfood from "@/assets/fastfood.jpg";
import drinks from "@/assets/drinks.jpg";
import dessert from "@/assets/dessert.jpg";

type Item = { name: string; price: string; desc: string };
type Cat = { id: string; name: string; img: string; items: Item[] };

const categories: Cat[] = [
  {
    id: "pizza", name: "Pizza", img: pizza,
    items: [
      { name: "Pizza Small", price: "Rs. 600", desc: "Crispy hand-stretched crust, cheese & tomato." },
      { name: "Pizza Medium", price: "Rs. 900", desc: "Loaded with mozzarella & signature sauce." },
      { name: "Pizza Large", price: "Rs. 1,250", desc: "Family favourite, generous toppings." },
      { name: "Tikka Special", price: "Rs. 1,150", desc: "Smoky chicken tikka, peppers, onions." },
    ],
  },
  {
    id: "burgers", name: "Burgers", img: burger,
    items: [
      { name: "Simple Burger", price: "Rs. 120", desc: "Classic patty, fresh veggies, soft bun." },
      { name: "Chicken Burger", price: "Rs. 150", desc: "Juicy chicken fillet, melted cheese." },
      { name: "Zinger Burger", price: "Rs. 250", desc: "Crispy spiced fillet with mayo." },
      { name: "Double Cheese Beef", price: "Rs. 350", desc: "Two patties, double cheese, signature sauce." },
    ],
  },
  {
    id: "bbq", name: "BBQ", img: bbq,
    items: [
      { name: "Chicken Tikka", price: "Rs. 320", desc: "Char-grilled, marinated overnight." },
      { name: "Seekh Kebab (4 pcs)", price: "Rs. 380", desc: "Hand-rolled spiced minced meat." },
      { name: "Malai Boti", price: "Rs. 450", desc: "Creamy, tender, melt-in-mouth." },
      { name: "BBQ Platter", price: "Rs. 1,500", desc: "An assortment for two with naan." },
    ],
  },
  {
    id: "fastfood", name: "Fast Food", img: fastfood,
    items: [
      { name: "French Fries", price: "Rs. 180", desc: "Golden, crispy, lightly salted." },
      { name: "Loaded Fries", price: "Rs. 280", desc: "Cheese, jalapeños & special sauce." },
      { name: "Chicken Wings (6)", price: "Rs. 420", desc: "Smoky, sticky, irresistible." },
      { name: "Crispy Strips", price: "Rs. 350", desc: "Hand-breaded, golden, served with dip." },
    ],
  },
  {
    id: "drinks", name: "Drinks", img: drinks,
    items: [
      { name: "Fresh Lime Mojito", price: "Rs. 220", desc: "Mint, lime, sparkling soda." },
      { name: "Mango Shake", price: "Rs. 250", desc: "Thick, creamy, seasonal mangoes." },
      { name: "Cold Coffee", price: "Rs. 280", desc: "Rich espresso blended with ice." },
      { name: "Soft Drink", price: "Rs. 80", desc: "Chilled bottle of your favourite." },
    ],
  },
  {
    id: "desserts", name: "Desserts", img: dessert,
    items: [
      { name: "Chocolate Lava Cake", price: "Rs. 320", desc: "Warm centre, vanilla scoop." },
      { name: "Cheesecake Slice", price: "Rs. 280", desc: "Classic NY-style, berry coulis." },
      { name: "Ice Cream Sundae", price: "Rs. 240", desc: "Triple scoop, nuts, syrup." },
      { name: "Fresh Pastries", price: "Rs. 150", desc: "Baked daily in our bakery." },
    ],
  },
];

export function Menu() {
  const [active, setActive] = useState(categories[0].id);
  const cat = categories.find((c) => c.id === active)!;

  return (
    <section id="menu" className="py-28 relative">
      <div className="container mx-auto px-5">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-xs uppercase tracking-[0.3em] text-accent font-semibold">Our Menu</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold mt-4 mb-4">
            A taste for <span className="text-gradient-gold">every craving</span>
          </h2>
          <p className="text-muted-foreground">From wood-fired pizza to char-grilled BBQ — every dish is crafted with care.</p>
        </div>

        <div className="flex flex-wrap justify-center gap-2 md:gap-3 mb-12">
          {categories.map((c) => (
            <button
              key={c.id}
              onClick={() => setActive(c.id)}
              className={`px-5 py-2.5 rounded-full text-sm font-medium transition-all ${
                active === c.id
                  ? "bg-gradient-gold text-primary-foreground shadow-glow"
                  : "glass text-muted-foreground hover:text-foreground"
              }`}
            >
              {c.name}
            </button>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8 items-start">
          <div className="lg:col-span-1 relative rounded-3xl overflow-hidden shadow-card group">
            <img src={cat.img} alt={cat.name} loading="lazy" className="w-full h-[400px] lg:h-[520px] object-cover transition-transform duration-700 group-hover:scale-110" />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent" />
            <div className="absolute bottom-6 left-6 right-6">
              <div className="text-xs uppercase tracking-[0.3em] text-accent">Featured</div>
              <h3 className="font-display text-3xl font-bold mt-2">{cat.name}</h3>
            </div>
          </div>

          <div className="lg:col-span-2 grid sm:grid-cols-2 gap-4">
            {cat.items.map((item, i) => (
              <div
                key={item.name}
                className="glass rounded-2xl p-6 hover-lift group animate-fade-up"
                style={{ animationDelay: `${i * 80}ms` }}
              >
                <div className="flex items-start justify-between gap-4 mb-2">
                  <h4 className="font-display text-xl font-semibold text-foreground group-hover:text-primary transition-colors">{item.name}</h4>
                  <span className="font-display font-bold text-gradient-gold whitespace-nowrap">{item.price}</span>
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
                <div className="mt-4 h-px bg-gradient-to-r from-primary/30 via-transparent to-transparent" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
