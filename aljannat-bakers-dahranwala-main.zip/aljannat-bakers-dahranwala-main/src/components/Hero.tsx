import hero from "@/assets/hero.jpg";
import { ArrowRight, Calendar, Pizza, Coffee, Cookie } from "lucide-react";

export function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center overflow-hidden">
      <div className="absolute inset-0">
        <img src={hero} alt="Cinematic gourmet pizza" className="w-full h-full object-cover scale-110" />
        <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/60 to-background" />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/40 to-transparent" />
      </div>

      {/* Floating elements */}
      <div className="absolute top-1/4 right-[10%] w-20 h-20 rounded-full bg-gradient-gold/20 blur-2xl animate-float" />
      <div className="absolute bottom-1/3 right-[20%] w-32 h-32 rounded-full bg-gradient-ember/20 blur-3xl animate-float-slow" />
      <div className="absolute top-1/3 right-[15%] hidden md:block animate-float">
        <div className="w-14 h-14 glass rounded-2xl flex items-center justify-center shadow-glow">
          <Pizza className="w-6 h-6 text-primary" />
        </div>
      </div>
      <div className="absolute top-2/3 right-[8%] hidden md:block animate-float-slow">
        <div className="w-14 h-14 glass rounded-2xl flex items-center justify-center shadow-ember">
          <Coffee className="w-6 h-6 text-accent" />
        </div>
      </div>
      <div className="absolute top-1/2 right-[25%] hidden md:block animate-float">
        <div className="w-14 h-14 glass rounded-2xl flex items-center justify-center">
          <Cookie className="w-6 h-6 text-primary" />
        </div>
      </div>

      <div className="container mx-auto px-5 relative z-10 pt-24">
        <div className="max-w-2xl animate-fade-up">
          <div className="inline-flex items-center gap-2 glass px-4 py-2 rounded-full mb-6">
            <span className="w-2 h-2 rounded-full bg-accent animate-pulse" />
            <span className="text-xs uppercase tracking-[0.25em] text-muted-foreground">Open 24 Hours · Dahranwala</span>
          </div>

          <h1 className="font-display text-5xl sm:text-6xl lg:text-8xl font-bold leading-[1.05] mb-6">
            <span className="text-gradient-gold">AL Jannat</span>
            <span className="block text-foreground">Bakers & Cafeteria</span>
          </h1>

          <p className="text-xl md:text-2xl font-display italic text-muted-foreground mb-3">
            "Fresh Food, Great Mood"
          </p>
          <p className="text-base text-muted-foreground/80 max-w-lg mb-10">
            A premium dining destination where flame-kissed BBQ, wood-fired pizza, and artisan cafe craft come together for unforgettable family moments.
          </p>

          <div className="flex flex-wrap gap-4">
            <a href="#order" className="btn-glow bg-gradient-gold text-primary-foreground px-8 py-4 rounded-full font-semibold inline-flex items-center gap-2 shadow-glow">
              Order Now <ArrowRight className="w-4 h-4" />
            </a>
            <a href="#reservation" className="btn-glow glass text-foreground px-8 py-4 rounded-full font-semibold inline-flex items-center gap-2 border border-primary/30">
              <Calendar className="w-4 h-4" /> Reserve Table
            </a>
          </div>

          <div className="mt-16 grid grid-cols-3 gap-6 max-w-md">
            {[
              { n: "12+", l: "Years" },
              { n: "50K+", l: "Happy Guests" },
              { n: "24/7", l: "Service" },
            ].map((s) => (
              <div key={s.l}>
                <div className="text-3xl font-display font-bold text-gradient-gold">{s.n}</div>
                <div className="text-xs uppercase tracking-widest text-muted-foreground mt-1">{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 text-muted-foreground text-xs tracking-[0.3em] uppercase animate-pulse">
        Scroll
      </div>
    </section>
  );
}
