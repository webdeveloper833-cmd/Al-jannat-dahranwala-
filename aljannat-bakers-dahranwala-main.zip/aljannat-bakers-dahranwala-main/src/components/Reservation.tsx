import { useState } from "react";
import { Calendar, Clock, Users, User, Phone, MessageSquare, Send } from "lucide-react";

export function Reservation() {
  const [submitted, setSubmitted] = useState(false);

  return (
    <section id="reservation" className="py-28 relative overflow-hidden">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-primary/10 blur-3xl rounded-full" />
      <div className="container mx-auto px-5 relative">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-12">
            <span className="text-xs uppercase tracking-[0.3em] text-accent font-semibold">Reserve Your Spot</span>
            <h2 className="font-display text-4xl md:text-5xl font-bold mt-4 mb-4">
              Book a <span className="text-gradient-gold">table</span>
            </h2>
            <p className="text-muted-foreground">A perfect evening starts with a simple booking.</p>
          </div>

          <form
            onSubmit={(e) => { e.preventDefault(); setSubmitted(true); setTimeout(() => setSubmitted(false), 4000); }}
            className="glass rounded-3xl p-6 md:p-10 shadow-card"
          >
            <div className="grid md:grid-cols-2 gap-5">
              <Field icon={User} label="Full Name" type="text" placeholder="Your name" />
              <Field icon={Phone} label="Phone" type="tel" placeholder="03XX-XXXXXXX" />
              <Field icon={Users} label="Guests" type="number" placeholder="2" />
              <Field icon={Calendar} label="Date" type="date" />
              <div className="md:col-span-2">
                <Field icon={Clock} label="Time" type="time" />
              </div>
              <div className="md:col-span-2">
                <label className="text-xs uppercase tracking-widest text-muted-foreground mb-2 block">Message</label>
                <div className="relative glass rounded-xl">
                  <MessageSquare className="absolute top-4 left-4 w-4 h-4 text-muted-foreground" />
                  <textarea rows={4} placeholder="Special requests..." className="w-full bg-transparent pl-11 pr-4 py-4 text-sm focus:outline-none resize-none" />
                </div>
              </div>
            </div>

            <button type="submit" className="mt-8 w-full btn-glow bg-gradient-gold text-primary-foreground font-semibold py-4 rounded-full inline-flex items-center justify-center gap-2 shadow-glow">
              {submitted ? "Reservation Sent ✓" : (<>Confirm Reservation <Send className="w-4 h-4" /></>)}
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}

function Field({ icon: Icon, label, type, placeholder }: { icon: any; label: string; type: string; placeholder?: string }) {
  return (
    <div>
      <label className="text-xs uppercase tracking-widest text-muted-foreground mb-2 block">{label}</label>
      <div className="relative glass rounded-xl">
        <Icon className="absolute top-1/2 -translate-y-1/2 left-4 w-4 h-4 text-muted-foreground" />
        <input type={type} placeholder={placeholder} className="w-full bg-transparent pl-11 pr-4 py-3.5 text-sm focus:outline-none" />
      </div>
    </div>
  );
}
