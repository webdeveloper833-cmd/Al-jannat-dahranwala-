import { UtensilsCrossed, Facebook, Instagram, MessageCircle } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t border-border pt-16 pb-8 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent to-primary/5 pointer-events-none" />
      <div className="container mx-auto px-5 relative">
        <div className="grid md:grid-cols-4 gap-10 mb-12">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <span className="w-10 h-10 rounded-full bg-gradient-gold flex items-center justify-center shadow-glow">
                <UtensilsCrossed className="w-5 h-5 text-primary-foreground" />
              </span>
              <span className="font-display font-bold text-lg">
                <span className="text-gradient-gold">AL Jannat</span>
                <span className="block text-[10px] tracking-[0.3em] text-muted-foreground uppercase">Bakers & Cafeteria</span>
              </span>
            </div>
            <p className="text-sm text-muted-foreground max-w-md leading-relaxed">
              A premium dining destination in Dahranwala — where fresh food meets great moods, 24 hours a day.
            </p>
            <div className="flex gap-3 mt-6">
              {[Facebook, Instagram, MessageCircle].map((Icon, i) => (
                <a key={i} href="#" className="w-10 h-10 glass rounded-full flex items-center justify-center hover:bg-gradient-gold hover:text-primary-foreground transition-all">
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-display font-bold mb-4 text-foreground">Quick Links</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              {["About", "Menu", "Offers", "Gallery", "Reservation"].map((l) => (
                <li key={l}><a href={`#${l.toLowerCase()}`} className="hover:text-primary transition-colors">{l}</a></li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-display font-bold mb-4 text-foreground">Contact</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>Main Bazaar, Dahranwala</li>
              <li>+92 300 0000000</li>
              <li>hello@aljannatcafe.com</li>
              <li className="text-accent">Open 24 Hours</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-border pt-6 flex flex-col md:flex-row justify-between items-center gap-3 text-xs text-muted-foreground">
          <div>© {new Date().getFullYear()} AL Jannat Bakers & Cafeteria. All rights reserved.</div>
          <div>Crafted with <span className="text-accent">♥</span> in Dahranwala, Pakistan</div>
        </div>
      </div>
    </footer>
  );
}
