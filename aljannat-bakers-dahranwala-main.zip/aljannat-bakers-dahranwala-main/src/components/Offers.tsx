import { Gift, Pizza, GraduationCap, Coffee } from "lucide-react";

const offers = [
  { icon: Gift, title: "Family Deal", price: "Rs. 1,999", desc: "2 Large Pizzas + 4 Burgers + 1.5L Drink", tag: "Best Value", grad: "from-primary/30 to-accent/30" },
  { icon: Pizza, title: "Pizza Night", price: "30% OFF", desc: "Every Friday on all large pizzas after 8 PM", tag: "Weekly", grad: "from-accent/30 to-crimson/30" },
  { icon: GraduationCap, title: "Student Discount", price: "20% OFF", desc: "Show valid ID & enjoy any meal under Rs. 500", tag: "All Day", grad: "from-primary/30 to-primary/10" },
  { icon: Coffee, title: "Free Drink", price: "FREE", desc: "Complimentary cold drink with any BBQ platter", tag: "Today", grad: "from-accent/30 to-primary/30" },
];

export function Offers() {
  return (
    <section id="offers" className="py-28 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/5 to-transparent" />
      <div className="container mx-auto px-5 relative">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-xs uppercase tracking-[0.3em] text-accent font-semibold">Limited Time</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold mt-4 mb-4">
            Special <span className="text-gradient-gold">Offers</span>
          </h2>
          <p className="text-muted-foreground">Hand-picked deals to make every visit unforgettable.</p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {offers.map((o, i) => (
            <div key={o.title} className="group relative animate-fade-up" style={{ animationDelay: `${i * 100}ms` }}>
              <div className={`absolute -inset-0.5 bg-gradient-to-br ${o.grad} rounded-3xl blur opacity-50 group-hover:opacity-100 transition-opacity`} />
              <div className="relative glass rounded-3xl p-6 h-full hover-lift">
                <div className="flex items-center justify-between mb-6">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-gold flex items-center justify-center shadow-glow">
                    <o.icon className="w-6 h-6 text-primary-foreground" />
                  </div>
                  <span className="text-[10px] uppercase tracking-widest px-2 py-1 rounded-full bg-accent/20 text-accent">{o.tag}</span>
                </div>
                <h3 className="font-display text-2xl font-bold mb-2">{o.title}</h3>
                <div className="text-gradient-gold font-display text-3xl font-bold mb-3">{o.price}</div>
                <p className="text-sm text-muted-foreground leading-relaxed">{o.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
