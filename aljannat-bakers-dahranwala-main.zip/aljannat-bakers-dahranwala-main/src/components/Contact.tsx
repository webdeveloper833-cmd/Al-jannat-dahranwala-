import { Phone, MapPin, Clock, Mail, Facebook, Instagram, MessageCircle } from "lucide-react";

export function Contact() {
  return (
    <section id="contact" className="py-28">
      <div className="container mx-auto px-5">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-xs uppercase tracking-[0.3em] text-accent font-semibold">Get in Touch</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold mt-4 mb-4">
            Visit us in <span className="text-gradient-gold">Dahranwala</span>
          </h2>
        </div>

        <div className="grid lg:grid-cols-5 gap-8">
          <div className="lg:col-span-2 space-y-4">
            <InfoCard icon={MapPin} title="Address" lines={["Main Bazaar, Dahranwala", "Punjab, Pakistan"]} />
            <InfoCard icon={Phone} title="Phone" lines={["+92 300 0000000", "+92 311 0000000"]} href="tel:+923000000000" />
            <InfoCard icon={Clock} title="Hours" lines={["Open 24 Hours", "Every Day of the Week"]} />
            <InfoCard icon={Mail} title="Email" lines={["hello@aljannatcafe.com"]} href="mailto:hello@aljannatcafe.com" />

            <div className="flex gap-3 pt-2">
              {[Facebook, Instagram, MessageCircle].map((Icon, i) => (
                <a key={i} href="#" className="w-12 h-12 glass rounded-full flex items-center justify-center hover:bg-gradient-gold hover:text-primary-foreground transition-all hover-lift">
                  <Icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          <div className="lg:col-span-3 rounded-3xl overflow-hidden glass shadow-card h-[520px]">
            <iframe
              title="AL Jannat Bakers & Cafeteria Location"
              src="https://www.google.com/maps?q=Dahranwala,Pakistan&output=embed"
              className="w-full h-full grayscale-[40%] contrast-110"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>
      </div>
    </section>
  );
}

function InfoCard({ icon: Icon, title, lines, href }: { icon: any; title: string; lines: string[]; href?: string }) {
  const Wrap: any = href ? "a" : "div";
  return (
    <Wrap href={href} className="glass rounded-2xl p-5 flex items-start gap-4 hover-lift block">
      <div className="w-12 h-12 rounded-xl bg-gradient-gold flex items-center justify-center shrink-0 shadow-glow">
        <Icon className="w-5 h-5 text-primary-foreground" />
      </div>
      <div>
        <div className="text-xs uppercase tracking-widest text-accent mb-1">{title}</div>
        {lines.map((l) => <div key={l} className="text-sm text-foreground">{l}</div>)}
      </div>
    </Wrap>
  );
}
