import dining from "@/assets/dining.jpg";
import { Leaf, ShieldCheck, Users, Sparkles } from "lucide-react";

const features = [
  { icon: Leaf, title: "Fresh Ingredients", desc: "Sourced daily, prepared with care." },
  { icon: ShieldCheck, title: "Hygienic Kitchen", desc: "Spotless, modern, certified standards." },
  { icon: Users, title: "Family Friendly", desc: "A warm space made for everyone." },
  { icon: Sparkles, title: "Crafted Flavors", desc: "Recipes refined over a decade." },
];

export function About() {
  return (
    <section id="about" className="py-28 relative overflow-hidden">
      <div className="absolute top-1/2 -left-32 w-96 h-96 rounded-full bg-primary/5 blur-3xl" />
      <div className="container mx-auto px-5">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="relative">
            <div className="relative rounded-3xl overflow-hidden shadow-card">
              <img src={dining} alt="Premium family dining at AL Jannat" loading="lazy" className="w-full h-[560px] object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-background/60 to-transparent" />
            </div>
            <div className="absolute -bottom-8 -right-4 md:-right-8 glass rounded-2xl p-6 shadow-glow max-w-[220px]">
              <div className="text-4xl font-display font-bold text-gradient-gold">4.9★</div>
              <p className="text-xs text-muted-foreground mt-1">Loved by 50,000+ guests across Dahranwala</p>
            </div>
            <div className="absolute -top-6 -left-6 hidden md:block w-24 h-24 border border-primary/30 rounded-2xl rotate-12" />
          </div>

          <div>
            <span className="text-xs uppercase tracking-[0.3em] text-accent font-semibold">Our Story</span>
            <h2 className="font-display text-4xl md:text-5xl font-bold mt-4 mb-6 leading-tight">
              Where every bite tells a <span className="text-gradient-gold">story of taste</span>.
            </h2>
            <p className="text-muted-foreground text-base leading-relaxed mb-5">
              AL Jannat Bakers & Cafeteria is Dahranwala's most-loved destination for fast food, sizzling BBQ, wood-fired pizza, signature burgers, fresh bakes, and barista-crafted coffee — all under one roof.
            </p>
            <p className="text-muted-foreground text-base leading-relaxed mb-10">
              From students grabbing a quick bite to families celebrating special moments and travelers exploring the region — we welcome everyone with warmth, generous portions, and a hygienic kitchen you can trust.
            </p>

            <div className="grid sm:grid-cols-2 gap-4">
              {features.map((f) => (
                <div key={f.title} className="glass rounded-2xl p-5 hover-lift">
                  <div className="w-11 h-11 rounded-xl bg-gradient-gold/20 flex items-center justify-center mb-3">
                    <f.icon className="w-5 h-5 text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-1">{f.title}</h3>
                  <p className="text-sm text-muted-foreground">{f.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
