import { useEffect, useState } from "react";
import { Star, Quote } from "lucide-react";

const reviews = [
  { name: "Ahmed Raza", role: "Local Foodie", text: "Hands down the best BBQ in Dahranwala. The kebabs are juicy, the service is warm, and the ambience feels truly premium." },
  { name: "Sana Malik", role: "Family Visitor", text: "We celebrated my daughter's birthday here. The pizza was perfect, staff went out of their way, and the décor is gorgeous." },
  { name: "Hassan Tariq", role: "University Student", text: "Affordable, super clean, and open 24/7. The student discount is a lifesaver. Their cold coffee is unreal." },
  { name: "Ayesha Khan", role: "Tourist from Lahore", text: "Stumbled upon this place during a road trip — best decision. Felt like a high-end Lahore restaurant. Will be back." },
];

export function Reviews() {
  const [i, setI] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setI((p) => (p + 1) % reviews.length), 5000);
    return () => clearInterval(t);
  }, []);

  return (
    <section className="py-28 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-primary/5 to-transparent" />
      <div className="container mx-auto px-5 relative">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-xs uppercase tracking-[0.3em] text-accent font-semibold">Loved by guests</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold mt-4 mb-4">
            What our <span className="text-gradient-gold">customers say</span>
          </h2>
        </div>

        <div className="max-w-3xl mx-auto relative">
          <Quote className="w-20 h-20 text-primary/20 absolute -top-8 -left-4" />
          <div className="glass rounded-3xl p-8 md:p-12 shadow-card text-center min-h-[280px] flex flex-col justify-center">
            <div className="flex justify-center gap-1 mb-5">
              {Array.from({ length: 5 }).map((_, k) => (
                <Star key={k} className="w-5 h-5 fill-primary text-primary" />
              ))}
            </div>
            <p key={i} className="text-lg md:text-xl font-display italic text-foreground mb-6 animate-fade-in leading-relaxed">
              "{reviews[i].text}"
            </p>
            <div>
              <div className="font-semibold text-foreground">{reviews[i].name}</div>
              <div className="text-xs uppercase tracking-widest text-muted-foreground mt-1">{reviews[i].role}</div>
            </div>
          </div>

          <div className="flex justify-center gap-2 mt-8">
            {reviews.map((_, k) => (
              <button
                key={k}
                onClick={() => setI(k)}
                className={`h-2 rounded-full transition-all ${k === i ? "w-10 bg-gradient-gold" : "w-2 bg-muted"}`}
                aria-label={`Review ${k + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
