import { MessageCircle } from "lucide-react";

export function WhatsAppButton() {
  return (
    <a
      href="https://wa.me/923000000000"
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat on WhatsApp"
      className="fixed bottom-6 right-6 z-40 w-14 h-14 rounded-full bg-gradient-ember flex items-center justify-center shadow-ember animate-glow-pulse hover:scale-110 transition-transform"
    >
      <MessageCircle className="w-6 h-6 text-foreground" />
      <span className="absolute inset-0 rounded-full bg-accent/40 animate-ping" />
    </a>
  );
}
