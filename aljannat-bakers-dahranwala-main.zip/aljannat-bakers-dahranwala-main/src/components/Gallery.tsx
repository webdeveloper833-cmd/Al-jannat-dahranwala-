import pizza from "@/assets/pizza.jpg";
import burger from "@/assets/burger.jpg";
import bbq from "@/assets/bbq.jpg";
import coffee from "@/assets/coffee.jpg";
import dessert from "@/assets/dessert.jpg";
import dining from "@/assets/dining.jpg";

const images = [
  { src: pizza, label: "Wood-fired Pizza", span: "md:col-span-2 md:row-span-2" },
  { src: burger, label: "Signature Burger", span: "" },
  { src: bbq, label: "Char-grilled BBQ", span: "" },
  { src: coffee, label: "Cafe Craft", span: "" },
  { src: dessert, label: "Sweet Indulgence", span: "" },
  { src: dining, label: "Family Dining", span: "md:col-span-2" },
];

export function Gallery() {
  return (
    <section id="gallery" className="py-28">
      <div className="container mx-auto px-5">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-xs uppercase tracking-[0.3em] text-accent font-semibold">Gallery</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold mt-4 mb-4">
            A feast for the <span className="text-gradient-gold">eyes</span>
          </h2>
          <p className="text-muted-foreground">Step inside our kitchen and dining experience.</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 auto-rows-[180px] md:auto-rows-[220px] gap-4">
          {images.map((img, i) => (
            <div
              key={i}
              className={`relative rounded-2xl overflow-hidden group cursor-pointer hover-lift ${img.span}`}
            >
              <img src={img.src} alt={img.label} loading="lazy" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent opacity-80 group-hover:opacity-100 transition-opacity" />
              <div className="absolute bottom-4 left-4 right-4 transform translate-y-2 group-hover:translate-y-0 transition-transform">
                <div className="text-[10px] uppercase tracking-[0.3em] text-accent">View</div>
                <h4 className="font-display text-lg font-semibold">{img.label}</h4>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
