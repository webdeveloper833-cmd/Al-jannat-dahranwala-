import { useEffect, useState } from "react";
import { Menu, X, UtensilsCrossed } from "lucide-react";

const links = [
  { href: "#home", label: "Home" },
  { href: "#about", label: "About" },
  { href: "#menu", label: "Menu" },
  { href: "#offers", label: "Offers" },
  { href: "#gallery", label: "Gallery" },
  { href: "#chefs", label: "Chefs" },
  { href: "#reservation", label: "Reserve" },
  { href: "#contact", label: "Contact" },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${scrolled ? "glass-strong py-3" : "py-5"}`}>
      <nav className="container mx-auto px-5 flex items-center justify-between">
        <a href="#home" className="flex items-center gap-2 group">
          <span className="w-10 h-10 rounded-full bg-gradient-gold flex items-center justify-center shadow-glow animate-glow-pulse">
            <UtensilsCrossed className="w-5 h-5 text-primary-foreground" />
          </span>
          <span className="font-display font-bold text-lg leading-tight">
            <span className="text-gradient-gold">AL Jannat</span>
            <span className="block text-[10px] tracking-[0.3em] text-muted-foreground uppercase">Bakers & Cafeteria</span>
          </span>
        </a>

        <ul className="hidden lg:flex items-center gap-8">
          {links.map((l) => (
            <li key={l.href}>
              <a href={l.href} className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors relative group">
                {l.label}
                <span className="absolute -bottom-1 left-0 w-0 h-px bg-gradient-gold group-hover:w-full transition-all duration-300" />
              </a>
            </li>
          ))}
        </ul>

        <a href="#reservation" className="hidden lg:inline-flex btn-glow bg-gradient-gold text-primary-foreground px-5 py-2.5 rounded-full text-sm font-semibold">
          Book a Table
        </a>

        <button onClick={() => setOpen(!open)} className="lg:hidden p-2 text-foreground">
          {open ? <X /> : <Menu />}
        </button>
      </nav>

      {open && (
        <div className="lg:hidden glass-strong border-t border-border animate-fade-in">
          <ul className="container mx-auto px-5 py-6 flex flex-col gap-4">
            {links.map((l) => (
              <li key={l.href}>
                <a href={l.href} onClick={() => setOpen(false)} className="block text-base text-foreground hover:text-primary transition-colors py-2">
                  {l.label}
                </a>
              </li>
            ))}
            <a href="#reservation" onClick={() => setOpen(false)} className="bg-gradient-gold text-primary-foreground text-center px-5 py-3 rounded-full font-semibold">
              Book a Table
            </a>
          </ul>
        </div>
      )}
    </header>
  );
}
