import { Truck, Sparkles, Smartphone, Clock4 } from "lucide-react";

const items = [
  { icon: Truck, title: "Fast Delivery", desc: "Hot food at your door in 30 minutes or less." },
  { icon: Sparkles, title: "Always Fresh", desc: "Cooked to order — never reheated, never frozen." },
  { icon: Smartphone, title: "Easy Ordering", desc: "WhatsApp, call, or walk in — your choice." },
  { icon: Clock4, title: "24/7 Service", desc: "Late-night cravings? We've got you covered." },
];

export function OrderOnline() {
  return (
    <section id="order" className="py-28">
      <div className="container mx-auto px-5">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-xs uppercase tracking-[0.3em] text-accent font-semibold">Order Online</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold mt-4 mb-4">
            Fresh food, <span className="text-gradient-gold">delivered fast</span>
          </h2>
          <p className="text-muted-foreground">Skip the wait. Order from anywhere, anytime.</p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {items.map((it, i) => (
            <div key={it.title} className="glass rounded-3xl p-7 text-center hover-lift animate-fade-up" style={{ animationDelay: `${i * 100}ms` }}>
              <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-gold flex items-center justify-center shadow-glow mb-5">
                <it.icon className="w-7 h-7 text-primary-foreground" />
              </div>
              <h3 className="font-display text-xl font-bold mb-2">{it.title}</h3>
              <p className="text-sm text-muted-foreground">{it.desc}</p>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <a href="https://wa.me/923000000000" target="_blank" rel="noopener" className="btn-glow inline-flex items-center gap-3 bg-gradient-ember text-foreground px-10 py-4 rounded-full font-semibold shadow-ember">
            Order on WhatsApp →
          </a>
        </div>
      </div>
    </section>
  );
}
